import { GoogleGenAI } from "@google/genai";
import { Hotspot, MapSettings } from "../types";

const getAIClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key not found");
  }
  return new GoogleGenAI({ apiKey });
};

export const generateCustomPluginCode = async (
  hotspots: Hotspot[],
  settings: MapSettings,
  userRequest: string
): Promise<string> => {
  try {
    const ai = getAIClient();
    
    const prompt = `
      You are an expert WordPress developer. 
      I have a list of image map hotspots and settings.
      
      Hotspots Data: ${JSON.stringify(hotspots)}
      Settings: ${JSON.stringify(settings)}
      
      The user wants to customize the WordPress PHP plugin code or CSS for this image map.
      
      User Request: "${userRequest}"
      
      Please provide the specific code snippet (PHP, CSS, or JS) that achieves this. 
      If it's a full PHP plugin update, provide the full file content.
      If it's just CSS, wrap it in <style> tags suitable for the WordPress Customizer or style.css.
      
      Keep the explanation brief and focus on the code.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });

    return response.text || "No response generated.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Error generating code. Please check your API Key and try again.";
  }
};
