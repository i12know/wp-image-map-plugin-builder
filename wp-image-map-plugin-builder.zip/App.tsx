import React, { useState, ChangeEvent } from 'react';
import { Upload, Image as ImageIcon } from 'lucide-react';
import EditorCanvas from './components/EditorCanvas';
import Sidebar from './components/Sidebar';
import CodeGenerator from './components/CodeGenerator';
import { Hotspot, MapSettings } from './types';

function App() {
  const [imageSrc, setImageSrc] = useState<string | null>(null);
  const [hotspots, setHotspots] = useState<Hotspot[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [isExporting, setIsExporting] = useState(false);
  
  const [settings, setSettings] = useState<MapSettings>({
    mapName: 'My Image Map',
    layout: 'tooltip',
    showTooltips: true,
    borderColor: '#3b82f6',
    borderWidth: 2,
  });

  const handleImageUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setImageSrc(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const addHotspot = (hotspot: Hotspot) => {
    setHotspots([...hotspots, hotspot]);
    setSelectedId(hotspot.id);
  };

  const updateHotspot = (id: string, updates: Partial<Hotspot>) => {
    setHotspots(hotspots.map(h => h.id === id ? { ...h, ...updates } : h));
  };

  const deleteHotspot = (id: string) => {
    setHotspots(hotspots.filter(h => h.id !== id));
    if (selectedId === id) setSelectedId(null);
  };

  return (
    <div className="flex flex-col h-screen bg-gray-50 overflow-hidden font-sans">
      {/* Navbar */}
      <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-6 shrink-0 z-20">
        <div className="flex items-center gap-2 text-indigo-600">
          <ImageIcon className="w-8 h-8" />
          <h1 className="text-xl font-bold tracking-tight text-gray-900">WP Image Map Builder</h1>
        </div>
        
        <div className="flex items-center gap-4">
          <label className="cursor-pointer flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-md transition-colors text-sm font-medium">
            <Upload size={16} />
            {imageSrc ? 'Change Image' : 'Upload Image'}
            <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
          </label>
        </div>
      </header>

      {/* Main Workspace */}
      <div className="flex flex-1 overflow-hidden">
        <EditorCanvas 
          imageSrc={imageSrc}
          hotspots={hotspots}
          selectedId={selectedId}
          onAddHotspot={addHotspot}
          onSelectHotspot={setSelectedId}
          onUpdateHotspot={updateHotspot}
        />
        <Sidebar 
          hotspots={hotspots}
          selectedId={selectedId}
          onUpdateHotspot={updateHotspot}
          onDeleteHotspot={deleteHotspot}
          settings={settings}
          onUpdateSettings={(s) => setSettings({...settings, ...s})}
          onExportClick={() => setIsExporting(true)}
        />
      </div>

      {/* Export Modal */}
      {isExporting && (
        <CodeGenerator 
          hotspots={hotspots}
          settings={settings}
          imageSrc={imageSrc}
          onClose={() => setIsExporting(false)}
        />
      )}
    </div>
  );
}

export default App;