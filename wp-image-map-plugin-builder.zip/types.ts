export interface Hotspot {
  id: string;
  x: number; // Percentage 0-100
  y: number; // Percentage 0-100
  width: number; // Percentage 0-100
  height: number; // Percentage 0-100
  title: string;
  description?: string;
  url: string;
}

export interface MapSettings {
  mapName: string;
  layout: 'tooltip' | 'info-panel'; // New layout option
  showTooltips: boolean;
  borderColor: string;
  borderWidth: number;
}