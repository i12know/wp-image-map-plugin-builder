import React, { useState } from 'react';
import { Hotspot, MapSettings } from '../types';
import { X, Copy, Check, Sparkles, Loader2, Download, Info, AlertTriangle, Terminal } from 'lucide-react';
import { generateCustomPluginCode } from '../services/geminiService';
import JSZip from 'jszip';

interface CodeGeneratorProps {
  hotspots: Hotspot[];
  settings: MapSettings;
  imageSrc: string | null;
  onClose: () => void;
}

const CodeGenerator: React.FC<CodeGeneratorProps> = ({ hotspots, settings, imageSrc, onClose }) => {
  const [activeTab, setActiveTab] = useState<'html' | 'plugin' | 'ai'>('plugin');
  const [copied, setCopied] = useState(false);
  const [isZipping, setIsZipping] = useState(false);
  
  // AI State
  const [aiPrompt, setAiPrompt] = useState('');
  const [aiResponse, setAiResponse] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);

  // Robust slug generation
  const cleanSlug = settings.mapName
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-') // Replace non-alphanumeric with hyphens
    .replace(/^-+|-+$/g, '')     // Remove leading/trailing hyphens
    || 'my-map';                 // Fallback

  const prefix = `wp-map-${cleanSlug}`;
  const isBase64 = imageSrc?.startsWith('data:');

  // Helper to convert base64 to binary for ZIP
  const parseDataUrl = (dataUrl: string) => {
    try {
      const arr = dataUrl.split(',');
      const mime = arr[0].match(/:(.*?);/)?.[1] || 'image/png';
      const bstr = atob(arr[1]);
      const n = bstr.length;
      const u8arr = new Uint8Array(n);
      for (let i = 0; i < n; i++) {
        u8arr[i] = bstr.charCodeAt(i);
      }
      const ext = mime.split('/')[1] === 'jpeg' ? 'jpg' : mime.split('/')[1];
      return { blob: new Blob([u8arr], { type: mime }), ext };
    } catch (e) {
      console.error("Error parsing image data", e);
      return null;
    }
  };

  // 1. CSS Logic (Responsive)
  const generateCSS = () => {
    // Base CSS for both modes
    let css = `
/* Screen Reader Only - Hides text visually but keeps it accessible */
.${prefix}-sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}

.${prefix}-wrapper {
  max-width: 100%;
}
.${prefix}-container {
  position: relative;
  display: block;
  width: 100%;
  max-width: 100%;
}
.${prefix}-img {
  display: block;
  width: 100%;
  height: auto;
}
.${prefix}-hotspot {
  position: absolute;
  border: ${settings.borderWidth}px solid transparent;
  transition: all 0.2s ease;
  z-index: 10;
  cursor: pointer;
}
.${prefix}-hotspot:hover, .${prefix}-hotspot.active {
  border-color: ${settings.borderColor};
  background-color: ${settings.borderColor}33; /* 20% opacity hex */
}`;

    // Mode Specific CSS
    if (settings.layout === 'tooltip' && settings.showTooltips) {
      css += `
.${prefix}-tooltip {
  visibility: hidden;
  background-color: #333;
  color: #fff;
  text-align: center;
  padding: 5px 10px;
  border-radius: 4px;
  position: absolute;
  z-index: 20;
  bottom: 100%;
  left: 50%;
  transform: translateX(-50%);
  white-space: nowrap;
  font-size: 12px;
  pointer-events: none;
  opacity: 0;
  transition: opacity 0.2s;
  margin-bottom: 5px;
}
.${prefix}-hotspot:hover .${prefix}-tooltip {
  visibility: visible;
  opacity: 1;
}`;
    } else if (settings.layout === 'info-panel') {
      css += `
/* Flex Layout for Info Panel Mode */
.${prefix}-wrapper {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  align-items: flex-start;
}
.${prefix}-container {
  flex: 2 1 600px; /* Grows to take space, wraps if < 600px available roughly */
}
.${prefix}-info-panel {
  flex: 1 1 300px;
  background-color: #f9fafb;
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  padding: 20px;
  min-height: 200px;
}
.${prefix}-info-title {
  margin-top: 0;
  font-size: 1.25rem;
  font-weight: 600;
  color: #111827;
  margin-bottom: 0.5rem;
}
.${prefix}-info-desc {
  font-size: 0.95rem;
  color: #4b5563;
  line-height: 1.5;
  margin-bottom: 1rem;
}
/* Styles for HTML content in description */
.${prefix}-info-desc p { margin-bottom: 0.75em; }
.${prefix}-info-desc ul { list-style-type: disc; margin-left: 1.25em; margin-bottom: 0.75em; }
.${prefix}-info-desc ol { list-style-type: decimal; margin-left: 1.25em; margin-bottom: 0.75em; }
.${prefix}-info-desc li { margin-bottom: 0.25em; }
.${prefix}-info-desc b, .${prefix}-info-desc strong { font-weight: 600; color: #111827; }
.${prefix}-info-desc i, .${prefix}-info-desc em { font-style: italic; }
.${prefix}-info-desc a { color: #2563eb; text-decoration: underline; }
.${prefix}-info-desc a:hover { color: #1d4ed8; }
.${prefix}-info-desc img { max-width: 100%; height: auto; border-radius: 4px; margin: 0.5em 0; border: 1px solid #e5e7eb; }

.${prefix}-info-cta {
  display: inline-block;
  background-color: #2563eb;
  color: white;
  padding: 8px 16px;
  border-radius: 4px;
  text-decoration: none;
  font-size: 0.875rem;
  font-weight: 500;
  transition: background-color 0.2s;
}
.${prefix}-info-cta:hover {
  background-color: #1d4ed8;
  color: white;
}
@media (max-width: 768px) {
  .${prefix}-wrapper {
    flex-direction: column;
  }
  .${prefix}-container, .${prefix}-info-panel {
    flex: 1 1 100%;
    width: 100%;
  }
}
`;
    }
    return css;
  };

  // 2. JS Logic (for interactivity in info panel mode)
  const generateJS = () => {
    if (settings.layout !== 'info-panel') return '';

    return `
<script>
document.addEventListener('DOMContentLoaded', function() {
  const hotspots = document.querySelectorAll('.${prefix}-hotspot');
  const titleEl = document.getElementById('${prefix}-title');
  const descEl = document.getElementById('${prefix}-desc');
  const ctaEl = document.getElementById('${prefix}-cta');

  hotspots.forEach(hotspot => {
    const updatePanel = () => {
      // Update UI Active State
      hotspots.forEach(h => h.classList.remove('active'));
      hotspot.classList.add('active');

      // Update Panel Content
      const title = hotspot.getAttribute('data-title');
      const desc = hotspot.getAttribute('data-desc') || '';
      const url = hotspot.getAttribute('href');

      if (titleEl) titleEl.innerText = title;
      if (descEl) descEl.innerHTML = desc; // Uses innerHTML to support basic formatting
      
      if (ctaEl) {
         if (url && url !== '#') {
           ctaEl.setAttribute('href', url);
           ctaEl.style.display = 'inline-block';
         } else {
           ctaEl.style.display = 'none';
         }
      }
    };

    // Update on hover
    hotspot.addEventListener('mouseenter', updatePanel);
    
    // Update on focus (keyboard navigation)
    hotspot.addEventListener('focus', updatePanel);

    // Click handler for touch devices or manual selection
    hotspot.addEventListener('click', function(e) {
      e.preventDefault(); // Prevent jump, user can use CTA button in panel
      updatePanel();
    });
  });
});
</script>
    `;
  };

  // 3. HTML Logic
  const generateHTML = () => {
    const defaultTitle = "Select an item";
    const defaultDesc = "Hover over highlighted areas in the image to view details here.";

    let html = `<div class="${prefix}-wrapper">`;
    
    // Image Container
    html += `
  <div class="${prefix}-container">
    <img src="${imageSrc || 'YOUR_IMAGE_URL_HERE'}" alt="${settings.mapName}" class="${prefix}-img" />
    ${hotspots.map(h => `
    <a href="${h.url}" 
       class="${prefix}-hotspot" 
       style="left: ${h.x}%; top: ${h.y}%; width: ${h.width}%; height: ${h.height}%;" 
       title="${h.title}"
       data-title="${h.title.replace(/"/g, '&quot;')}"
       data-desc="${(h.description || '').replace(/"/g, '&quot;')}"
    >
      ${settings.layout === 'tooltip' && settings.showTooltips ? `<span class="${prefix}-tooltip">${h.title}</span>` : ''}
      <span class="${prefix}-sr-only">${h.title}</span>
    </a>`).join('')}
  </div>`;

    // Info Panel
    if (settings.layout === 'info-panel') {
      html += `
  <div class="${prefix}-info-panel">
    <h3 class="${prefix}-info-title" id="${prefix}-title">${defaultTitle}</h3>
    <div class="${prefix}-info-desc" id="${prefix}-desc">${defaultDesc}</div>
    <a href="#" class="${prefix}-info-cta" id="${prefix}-cta" style="display:none">View Details</a>
  </div>`;
    }

    html += `</div>`;
    
    // Append JS for Info Panel
    if (settings.layout === 'info-panel') {
      html += generateJS();
    }

    return html;
  };

  // 4. WordPress Plugin PHP Logic
  // Now accepts an optional imageFilename. If present, it generates a plugin URL reference.
  const generatePluginPHP = (assetFilename?: string) => {
    
    // Determine the Source string for the img tag
    let imgSrcPHP = '';
    
    if (assetFilename) {
      // Logic for using a local asset file in the ZIP
      imgSrcPHP = `<?php echo plugins_url( 'assets/${assetFilename}', __FILE__ ); ?>`;
    } else {
      // Logic for using the Base64 string (Preview mode)
      imgSrcPHP = imageSrc || 'YOUR_IMAGE_URL_HERE';
    }

    return `<?php
/**
 * Plugin Name: ${settings.mapName} Image Map
 * Description: A responsive image map generated by WP Image Map Builder.
 * Version: 1.0
 * Author: WP Image Map Builder
 */

if (!defined('ABSPATH')) exit; // Exit if accessed directly

function ${prefix.replace(/-/g, '_')}_shortcode($atts) {
    // Unique ID for this instance
    $uid = uniqid(); 

    // Enqueue styles inline
    $css = '
    <style>
      ${generateCSS().replace(/\n/g, '')}
    </style>';

    // The Content
    ob_start();
    ?>
    <div class="${prefix}-wrapper" id="${prefix}-wrapper-<?php echo $uid; ?>">
      <div class="${prefix}-container">
        <img src="${imgSrcPHP}" alt="${settings.mapName}" class="${prefix}-img" />
        ${hotspots.map(h => `
        <a href="${h.url}" 
           class="${prefix}-hotspot" 
           style="left: ${h.x}%; top: ${h.y}%; width: ${h.width}%; height: ${h.height}%;"
           data-title="${h.title.replace(/"/g, '&quot;')}"
           data-desc="${(h.description || '').replace(/"/g, '&quot;')}"
        >
          ${settings.layout === 'tooltip' && settings.showTooltips ? `<span class="${prefix}-tooltip">${h.title}</span>` : ''}
          <span class="${prefix}-sr-only">${h.title}</span>
        </a>`).join('')}
      </div>

      <?php if ('${settings.layout}' === 'info-panel'): ?>
      <div class="${prefix}-info-panel">
        <h3 class="${prefix}-info-title" id="${prefix}-title-<?php echo $uid; ?>">Select an item</h3>
        <div class="${prefix}-info-desc" id="${prefix}-desc-<?php echo $uid; ?>">Hover over highlights to view details.</div>
        <a href="#" class="${prefix}-info-cta" id="${prefix}-cta-<?php echo $uid; ?>" style="display:none">View Details</a>
      </div>
      
      <script>
      (function() {
        var wrapper = document.getElementById('${prefix}-wrapper-<?php echo $uid; ?>');
        var titleEl = document.getElementById('${prefix}-title-<?php echo $uid; ?>');
        var descEl = document.getElementById('${prefix}-desc-<?php echo $uid; ?>');
        var ctaEl = document.getElementById('${prefix}-cta-<?php echo $uid; ?>');
        
        if (!wrapper) return;
        
        var hotspots = wrapper.querySelectorAll('.${prefix}-hotspot');
        
        hotspots.forEach(function(hotspot) {
          var updatePanel = function() {
             // Remove active class from all
             hotspots.forEach(function(h) { h.classList.remove('active'); });
             hotspot.classList.add('active');

             var title = hotspot.getAttribute('data-title');
             var desc = hotspot.getAttribute('data-desc');
             var url = hotspot.getAttribute('href');

             if (titleEl) titleEl.innerText = title;
             if (descEl) descEl.innerHTML = desc; // Uses innerHTML
             
             if (ctaEl) {
               if (url && url !== '#') {
                 ctaEl.href = url;
                 ctaEl.style.display = 'inline-block';
               } else {
                 ctaEl.style.display = 'none';
               }
             }
          };

          // Mouse Hover
          hotspot.addEventListener('mouseenter', updatePanel);
          
          // Keyboard Focus
          hotspot.addEventListener('focus', updatePanel);

          // Click (Touch/Fallback)
          hotspot.addEventListener('click', function(e) {
             e.preventDefault();
             updatePanel();
          });
        });
      })();
      </script>
      <?php endif; ?>
    </div>
    <?php
    $html = ob_get_clean();

    return $css . $html;
}

add_shortcode('${prefix}', '${prefix.replace(/-/g, '_')}_shortcode');
?>
`;
  };

  const getContent = () => {
    if (activeTab === 'html') return `<style>${generateCSS()}</style>\n${generateHTML()}`;
    // Default to Base64 in preview so Copy/Paste works without files, but inform user
    if (activeTab === 'plugin') return generatePluginPHP(); 
    return aiResponse || "Enter a prompt below to generate custom code...";
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(getContent());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadZip = async () => {
    setIsZipping(true);
    try {
      const zip = new JSZip();
      
      const pluginFolder = `wp-image-map-${cleanSlug}`;
      const folder = zip.folder(pluginFolder);
      
      let assetFilename: string | undefined = undefined;

      if (folder) {
        // Handle Image Separation
        if (imageSrc && isBase64) {
          const parsed = parseDataUrl(imageSrc);
          if (parsed) {
            assetFilename = `map-image.${parsed.ext}`;
            const assets = folder.folder('assets');
            if (assets) {
              assets.file(assetFilename, parsed.blob);
            }
          }
        }

        // Main PHP file - Pass the filename if we extracted it
        folder.file(`${pluginFolder}.php`, generatePluginPHP(assetFilename));
        
        // Readme
        folder.file('readme.txt', `=== ${settings.mapName} Image Map ===\n\nGenerated by WP Image Map Builder.\n\n== Installation ==\n\n1. Upload the plugin folder to wp-content/plugins/\n2. Activate the plugin\n3. Use shortcode [${prefix}]`);
      }

      // Generate Blob
      const content = await zip.generateAsync({ type: "blob" });
      
      // Download
      const url = window.URL.createObjectURL(content);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${pluginFolder}.zip`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (err) {
      console.error("Failed to zip:", err);
      alert("Error creating ZIP file");
    } finally {
      setIsZipping(false);
    }
  };

  const handleAskAI = async () => {
    if (!aiPrompt.trim()) return;
    setIsAiLoading(true);
    const result = await generateCustomPluginCode(hotspots, settings, aiPrompt);
    setAiResponse(result);
    setIsAiLoading(false);
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-4xl h-[85vh] flex flex-col overflow-hidden">
        
        {/* Header */}
        <div className="flex justify-between items-center p-6 border-b border-gray-100 bg-gray-50">
          <div>
            <h2 className="text-2xl font-bold text-gray-800">Export Image Map</h2>
            <div className="flex items-center gap-2 mt-2">
               <div className="text-sm font-medium text-gray-500">Your Shortcode:</div>
               <div className="font-mono text-sm bg-blue-100 text-blue-800 px-2 py-1 rounded select-all border border-blue-200">
                 [{prefix}]
               </div>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-gray-200 rounded-full transition-colors">
            <X size={24} />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-gray-200 px-6 shrink-0">
          <button 
            onClick={() => setActiveTab('plugin')}
            className={`px-6 py-3 font-medium text-sm border-b-2 transition-colors ${activeTab === 'plugin' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
          >
            WP Plugin (PHP)
          </button>
          <button 
            onClick={() => setActiveTab('html')}
            className={`px-6 py-3 font-medium text-sm border-b-2 transition-colors ${activeTab === 'html' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
          >
            Raw HTML/CSS
          </button>
          <button 
            onClick={() => setActiveTab('ai')}
            className={`px-6 py-3 font-medium text-sm border-b-2 transition-colors flex items-center gap-2 ${activeTab === 'ai' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
          >
            <Sparkles size={16} /> AI Assistant
          </button>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-hidden relative flex flex-col">
          {activeTab === 'ai' ? (
             <div className="flex flex-col h-full p-6 bg-gray-50">
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-2">How do you want to modify the plugin?</label>
                  <div className="flex gap-2">
                    <input 
                      type="text" 
                      value={aiPrompt}
                      onChange={(e) => setAiPrompt(e.target.value)}
                      placeholder="e.g. 'Make the tooltips fade in with a bounce animation' or 'Open links in a modal'"
                      className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                    />
                    <button 
                      onClick={handleAskAI}
                      disabled={isAiLoading || !process.env.API_KEY}
                      className="bg-indigo-600 text-white px-6 py-2 rounded-lg font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                    >
                      {isAiLoading ? <Loader2 className="animate-spin" size={18} /> : <Sparkles size={18} />}
                      Generate
                    </button>
                  </div>
                  {!process.env.API_KEY && (
                    <p className="text-xs text-red-500 mt-2">API Key missing. Please set REACT_APP_API_KEY environment variable.</p>
                  )}
                </div>
                <div className="flex-1 bg-gray-900 rounded-lg p-4 overflow-auto border border-gray-700">
                  <pre className="text-gray-300 font-mono text-sm whitespace-pre-wrap">
                    {isAiLoading ? "Asking Gemini..." : (aiResponse || "Results will appear here.")}
                  </pre>
                </div>
             </div>
          ) : activeTab === 'plugin' ? (
             <div className="flex flex-col md:flex-row h-full">
                <div className="flex-1 bg-gray-900 overflow-auto p-4 border-r border-gray-700 order-2 md:order-1 relative">
                   {isBase64 && (
                     <div className="mb-4 p-3 bg-yellow-900/50 border border-yellow-600 rounded text-yellow-200 text-xs flex items-start gap-2">
                       <AlertTriangle size={16} className="shrink-0 mt-0.5" />
                       <div>
                         <strong>Preview Mode:</strong> The code below embeds the image as Base64 for easy copying. 
                         <br/>
                         <span className="text-yellow-100">
                         For a production-ready version that stores the image in an <code>/assets</code> folder, please use the <strong>Download .zip</strong> button.
                         </span>
                       </div>
                     </div>
                   )}
                   <pre className="text-green-400 font-mono text-sm">
                     {getContent()}
                   </pre>
                </div>
                <div className="w-full md:w-80 bg-gray-50 p-6 overflow-y-auto border-l border-gray-200 shadow-inner order-1 md:order-2">
                  <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
                     <Info size={18} className="text-blue-600"/> Installation Guide
                  </h3>
                  <ol className="list-decimal space-y-4 pl-4 text-sm text-gray-600 marker:font-bold marker:text-gray-400">
                    <li>
                      <span className="font-medium text-gray-900">Download</span> the plugin ZIP file.
                    </li>
                    <li>
                      Go to <span className="font-medium text-gray-900">Plugins &gt; Add New &gt; Upload Plugin</span> in WordPress.
                    </li>
                    <li>
                      Upload and <span className="font-medium text-gray-900">Activate</span> the plugin.
                    </li>
                    <li>
                      <strong>Crucial:</strong> Use the exact shortcode below on your page. If you change the Map Name later, this shortcode will change!
                      <div 
                        className="mt-2 p-3 bg-white border-2 border-indigo-100 rounded-lg font-mono text-xs select-all cursor-pointer hover:border-indigo-400 transition-colors text-indigo-900 break-all flex items-center gap-2 group shadow-sm"
                        onClick={() => {
                          navigator.clipboard.writeText(`[${prefix}]`);
                          alert(`Shortcode [${prefix}] copied!`);
                        }}
                        title="Click to copy"
                      >
                        <Terminal size={14} className="text-indigo-400 group-hover:text-indigo-600"/>
                        [{prefix}]
                      </div>
                    </li>
                  </ol>
                </div>
             </div>
          ) : (
            <div className="flex-1 bg-gray-900 overflow-auto p-4">
               <pre className="text-green-400 font-mono text-sm">
                 {getContent()}
               </pre>
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="p-4 border-t border-gray-200 bg-gray-50 flex justify-end gap-3 shrink-0">
          <button 
            onClick={handleCopy} 
            className="flex items-center gap-2 px-6 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 font-medium text-gray-700 transition-colors"
          >
            {copied ? <Check size={18} className="text-green-600" /> : <Copy size={18} />}
            {copied ? 'Copied!' : 'Copy Code'}
          </button>
          {activeTab === 'plugin' && (
            <button 
              onClick={handleDownloadZip}
              disabled={isZipping}
              className="flex items-center gap-2 px-6 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 font-medium shadow-sm transition-colors disabled:opacity-70 disabled:cursor-not-allowed"
            >
               {isZipping ? <Loader2 size={18} className="animate-spin" /> : <Download size={18} />}
              Download .zip
            </button>
          )}
        </div>

      </div>
    </div>
  );
};

export default CodeGenerator;