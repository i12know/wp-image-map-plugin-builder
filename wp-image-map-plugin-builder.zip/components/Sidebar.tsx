import React from 'react';
import { Hotspot, MapSettings } from '../types';
import { Trash2, Link as LinkIcon, Type, Settings2, AlignLeft, Layout } from 'lucide-react';

interface SidebarProps {
  hotspots: Hotspot[];
  selectedId: string | null;
  onUpdateHotspot: (id: string, updates: Partial<Hotspot>) => void;
  onDeleteHotspot: (id: string) => void;
  settings: MapSettings;
  onUpdateSettings: (settings: Partial<MapSettings>) => void;
  onExportClick: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({
  hotspots,
  selectedId,
  onUpdateHotspot,
  onDeleteHotspot,
  settings,
  onUpdateSettings,
  onExportClick
}) => {
  const selectedHotspot = hotspots.find(h => h.id === selectedId);

  return (
    <div className="w-80 bg-white border-l border-gray-200 flex flex-col h-full shadow-lg z-10">
      
      {/* Header */}
      <div className="p-4 border-b border-gray-100">
        <h2 className="font-bold text-gray-800 text-lg">Properties</h2>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        
        {/* Selection Editor */}
        {selectedHotspot ? (
          <div className="space-y-4 animate-in fade-in slide-in-from-right-4 duration-300">
             <div className="flex justify-between items-center mb-2">
                <h3 className="text-sm font-semibold text-blue-600 uppercase tracking-wide">Selected Hotspot</h3>
                <button 
                  onClick={() => onDeleteHotspot(selectedHotspot.id)}
                  className="text-red-500 hover:text-red-700 p-1 rounded hover:bg-red-50 transition-colors"
                  title="Delete Hotspot"
                >
                  <Trash2 size={16} />
                </button>
             </div>

             <div className="space-y-3">
                <div>
                  <label className="block text-xs font-medium text-gray-500 mb-1 flex items-center gap-1">
                    <Type size={12} /> Title
                  </label>
                  <input
                    type="text"
                    value={selectedHotspot.title}
                    onChange={(e) => onUpdateHotspot(selectedHotspot.id, { title: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                    placeholder="e.g. Product Details"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-gray-500 mb-1 flex items-center gap-1">
                    <AlignLeft size={12} /> Description
                  </label>
                  <textarea
                    value={selectedHotspot.description || ''}
                    onChange={(e) => onUpdateHotspot(selectedHotspot.id, { description: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-500 outline-none min-h-[120px]"
                    placeholder="Enter description... (HTML supported: <b>, <i>, <ul>, <img src='...'>, <br>)"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-gray-500 mb-1 flex items-center gap-1">
                    <LinkIcon size={12} /> Target URL
                  </label>
                  <input
                    type="text"
                    value={selectedHotspot.url}
                    onChange={(e) => onUpdateHotspot(selectedHotspot.id, { url: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                    placeholder="https://..."
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-2">
                   <div className="p-2 bg-gray-50 rounded text-xs text-gray-500">
                      X: {selectedHotspot.x.toFixed(1)}%
                   </div>
                   <div className="p-2 bg-gray-50 rounded text-xs text-gray-500">
                      Y: {selectedHotspot.y.toFixed(1)}%
                   </div>
                   <div className="p-2 bg-gray-50 rounded text-xs text-gray-500">
                      W: {selectedHotspot.width.toFixed(1)}%
                   </div>
                   <div className="p-2 bg-gray-50 rounded text-xs text-gray-500">
                      H: {selectedHotspot.height.toFixed(1)}%
                   </div>
                </div>
             </div>
          </div>
        ) : (
          <div className="text-center py-8 text-gray-400 bg-gray-50 rounded-lg border border-dashed border-gray-200">
            <p className="text-sm">Select a hotspot on the image<br/>to edit its properties.</p>
          </div>
        )}

        {/* Global Settings */}
        <div className="pt-6 border-t border-gray-100">
           <h3 className="text-sm font-semibold text-gray-700 uppercase tracking-wide mb-4 flex items-center gap-2">
             <Settings2 size={16} /> Global Settings
           </h3>
           
           <div className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-gray-500 mb-1">Map Name (for ID)</label>
                <input
                  type="text"
                  value={settings.mapName}
                  onChange={(e) => onUpdateSettings({ mapName: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-gray-500 mb-2 flex items-center gap-1">
                  <Layout size={12} /> Display Layout
                </label>
                <div className="space-y-2">
                  <label className="flex items-center gap-2 p-2 rounded border border-gray-200 cursor-pointer hover:bg-gray-50">
                    <input 
                      type="radio" 
                      name="layout"
                      checked={settings.layout === 'tooltip'}
                      onChange={() => onUpdateSettings({ layout: 'tooltip' })}
                      className="text-blue-600 focus:ring-blue-500"
                    />
                    <div className="text-sm">
                      <span className="font-medium block text-gray-700">Tooltip Overlay</span>
                      <span className="text-xs text-gray-500">Simple tooltips on hover</span>
                    </div>
                  </label>
                  
                  <label className="flex items-center gap-2 p-2 rounded border border-gray-200 cursor-pointer hover:bg-gray-50">
                    <input 
                      type="radio" 
                      name="layout"
                      checked={settings.layout === 'info-panel'}
                      onChange={() => onUpdateSettings({ layout: 'info-panel' })}
                      className="text-blue-600 focus:ring-blue-500"
                    />
                    <div className="text-sm">
                      <span className="font-medium block text-gray-700">Info Panel (Split View)</span>
                      <span className="text-xs text-gray-500">Details next to image (desktop) or below (mobile)</span>
                    </div>
                  </label>
                </div>
              </div>

              {settings.layout === 'tooltip' && (
                <div className="flex items-center gap-2">
                   <input 
                      type="checkbox" 
                      id="showTooltips"
                      checked={settings.showTooltips}
                      onChange={(e) => onUpdateSettings({ showTooltips: e.target.checked })}
                      className="rounded text-blue-600 focus:ring-blue-500 h-4 w-4"
                   />
                   <label htmlFor="showTooltips" className="text-sm text-gray-700 select-none">Show Tooltips on Hover</label>
                </div>
              )}

              <div>
                <label className="block text-xs font-medium text-gray-500 mb-1">Border Highlight Color</label>
                <div className="flex gap-2">
                  <input
                    type="color"
                    value={settings.borderColor}
                    onChange={(e) => onUpdateSettings({ borderColor: e.target.value })}
                    className="h-8 w-8 rounded cursor-pointer border-0 p-0"
                  />
                  <input 
                     type="text"
                     value={settings.borderColor}
                     onChange={(e) => onUpdateSettings({ borderColor: e.target.value })}
                     className="flex-1 px-2 py-1 border border-gray-300 rounded text-sm uppercase"
                  />
                </div>
              </div>
           </div>
        </div>
      </div>

      {/* Footer / Generate */}
      <div className="p-4 border-t border-gray-200 bg-gray-50">
        <button 
          onClick={onExportClick}
          className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-4 rounded-lg shadow transition-all transform active:scale-95 flex items-center justify-center gap-2"
        >
          Generate Plugin Code
        </button>
      </div>
    </div>
  );
};

export default Sidebar;