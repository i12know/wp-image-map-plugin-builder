import React, { useRef, useState, useEffect, MouseEvent } from 'react';
import { Hotspot } from '../types';
import { MousePointer2, Plus } from 'lucide-react';

interface EditorCanvasProps {
  imageSrc: string | null;
  hotspots: Hotspot[];
  selectedId: string | null;
  onAddHotspot: (hotspot: Hotspot) => void;
  onSelectHotspot: (id: string | null) => void;
  onUpdateHotspot: (id: string, updates: Partial<Hotspot>) => void;
}

const EditorCanvas: React.FC<EditorCanvasProps> = ({
  imageSrc,
  hotspots,
  selectedId,
  onAddHotspot,
  onSelectHotspot,
  onUpdateHotspot
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [startPos, setStartPos] = useState<{ x: number; y: number } | null>(null);
  const [currentPos, setCurrentPos] = useState<{ x: number; y: number } | null>(null);

  // Helper to get coordinates in percentage relative to container
  const getCoords = (e: MouseEvent) => {
    if (!containerRef.current) return { x: 0, y: 0 };
    const rect = containerRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    return { x: Math.max(0, Math.min(100, x)), y: Math.max(0, Math.min(100, y)) };
  };

  const handleMouseDown = (e: MouseEvent) => {
    if (!imageSrc) return;
    // If clicking a hotspot, prevent drawing
    if ((e.target as HTMLElement).closest('.hotspot-box')) return;

    setIsDrawing(true);
    const coords = getCoords(e);
    setStartPos(coords);
    setCurrentPos(coords);
    onSelectHotspot(null); // Deselect when starting to draw
  };

  const handleMouseMove = (e: MouseEvent) => {
    if (!isDrawing || !startPos) return;
    setCurrentPos(getCoords(e));
  };

  const handleMouseUp = () => {
    if (!isDrawing || !startPos || !currentPos) return;

    const width = Math.abs(currentPos.x - startPos.x);
    const height = Math.abs(currentPos.y - startPos.y);

    // Minimum size threshold to avoid accidental clicks creating tiny boxes
    if (width > 2 && height > 2) {
      const x = Math.min(startPos.x, currentPos.x);
      const y = Math.min(startPos.y, currentPos.y);
      
      const newHotspot: Hotspot = {
        id: crypto.randomUUID(),
        x,
        y,
        width,
        height,
        title: 'New Link',
        url: '#'
      };
      onAddHotspot(newHotspot);
    }

    setIsDrawing(false);
    setStartPos(null);
    setCurrentPos(null);
  };

  return (
    <div className="flex-1 bg-gray-100 flex items-center justify-center p-8 overflow-auto min-h-[500px]">
      {!imageSrc ? (
        <div className="text-gray-400 text-center">
          <MousePointer2 className="w-16 h-16 mx-auto mb-4 opacity-50" />
          <p className="text-lg font-medium">Upload an image to start building</p>
        </div>
      ) : (
        <div 
          ref={containerRef}
          className="relative shadow-xl cursor-crosshair select-none inline-block max-w-full"
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={() => isDrawing && setIsDrawing(false)}
        >
          <img 
            src={imageSrc} 
            alt="Map Source" 
            className="max-w-full max-h-[70vh] block pointer-events-none" 
            draggable={false}
          />
          
          {/* Render Existing Hotspots */}
          {hotspots.map((h) => (
            <div
              key={h.id}
              onClick={(e) => {
                e.stopPropagation();
                onSelectHotspot(h.id);
              }}
              className={`hotspot-box absolute border-2 transition-colors cursor-pointer group ${
                selectedId === h.id 
                  ? 'border-blue-500 bg-blue-500/20 z-20' 
                  : 'border-white/80 bg-black/10 hover:bg-black/20 z-10'
              }`}
              style={{
                left: `${h.x}%`,
                top: `${h.y}%`,
                width: `${h.width}%`,
                height: `${h.height}%`,
              }}
            >
              {/* Tooltip on hover in editor */}
              <div className="opacity-0 group-hover:opacity-100 absolute -top-8 left-0 bg-black text-white text-xs px-2 py-1 rounded whitespace-nowrap pointer-events-none">
                {h.title}
              </div>
              
              {/* Handles for selected item could go here */}
            </div>
          ))}

          {/* Render Drawing Preview */}
          {isDrawing && startPos && currentPos && (
            <div
              className="absolute border-2 border-green-400 bg-green-400/20 z-30"
              style={{
                left: `${Math.min(startPos.x, currentPos.x)}%`,
                top: `${Math.min(startPos.y, currentPos.y)}%`,
                width: `${Math.abs(currentPos.x - startPos.x)}%`,
                height: `${Math.abs(currentPos.y - startPos.y)}%`,
              }}
            />
          )}
        </div>
      )}
    </div>
  );
};

export default EditorCanvas;
